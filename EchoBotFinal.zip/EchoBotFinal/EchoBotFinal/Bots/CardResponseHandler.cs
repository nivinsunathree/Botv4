﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EchoBotFinal.Bots
{
    public class CardResponseHandler
    {
        //when user doesn't have a ref id, chooses no
        public void MenuCardResponse()
        {
            
        }
    }
}
