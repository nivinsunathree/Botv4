// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
//
// Generated with Bot Builder V4 SDK Template for Visual Studio EchoBot v4.3.0

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using EchoBotFinal.Models;
using EchoBotFinal.Service;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Activity = Microsoft.Bot.Schema.Activity;
using System.Net.Mail;
using Attachment = Microsoft.Bot.Schema.Attachment;
using System.Net;
using System.Text;
using Microsoft.Bot.Connector;
using Microsoft.Bot.Schema.Teams;
using Microsoft.Extensions.Logging;
using Microsoft.Bot.Connector.Teams;
using System.Net.Http;
using System.Security.Claims;
using Microsoft.Bot.Connector.Authentication;
using Microsoft.Extensions.Configuration;
using Microsoft.Bot.Builder.BotFramework;

namespace EchoBotFinal.Bots
{
    public class EchoBot : ActivityHandler
    {
        public static string searchQuery = "";
        public static string ticketNumberThatClosed = "";
        const double interval60Minutes2 = 5 * 1000; //for state change



        const double interval60Minutes = 5 * 1000; // for new tickets arriving
        static string name;
        static string name2;
        static string currIntent;
        
        static bool startCommentResult = false;
        static int countComment = 0;
        static List<KeyValuePair<string, string>> dailyReportingList = new List<KeyValuePair<string, string>>();
        static bool startAccessRequestFlow = false;
        static int countAccessRequest = 0;
        static bool haveRefId = false;
        public static bool triggerSubmenu = false;
        static string menuandsubmenu;
        static string menu;
        static string submenu;
        public static bool recordSubmenu = false;
        static bool accessRequestTriggeredOnce = false;
        static bool selectMoreSubmenu = false;
        static bool timeNotSpecified = false;
        static bool specifyTicketNumForStateChange = false;
        

        //for file menu submenu recording
        static string appname = "";
        static string requestedUser = "";
        static string site = "";
        static string refId = "";

        //for notification
        public static List<KeyValuePair<string, string>> savedSearchesList = new List<KeyValuePair<string, string>>();

        //shay
        static bool descriptionGiven = false;
        static bool askforAppName = false;
        static bool askForErrorMsg = false;
        static bool askForDocSummary = false;
        static bool categoryOfIssues = false;
        static bool AppName = false;
        static bool addToList = false;
        private BotState _conversationState;
        private BotState _userState;

        //proactivebot
        private ConcurrentDictionary<string, ConversationReference> _conversationReferences;

        public EchoBot(ConcurrentDictionary<string, ConversationReference> conversationReferences, ConversationState conversationState, UserState userState)
        {
            _conversationReferences = conversationReferences;
            _conversationState = conversationState;
            _userState = userState;



        }

        private void AddConversationReference(Activity activity)
        {
            var conversationReference = activity.GetConversationReference();
            _conversationReferences.AddOrUpdate(conversationReference.User.Id, conversationReference, (key, newValue) => conversationReference);
        }

        protected override Task OnConversationUpdateActivityAsync(ITurnContext<IConversationUpdateActivity> turnContext, CancellationToken cancellationToken)
        {
            AddConversationReference(turnContext.Activity as Activity);

            return base.OnConversationUpdateActivityAsync(turnContext, cancellationToken);
			
        }
		
		
        public override async Task OnTurnAsync(ITurnContext turnContext, CancellationToken cancellationToken = default(CancellationToken))
        {
            await base.OnTurnAsync(turnContext, cancellationToken);
            System.Timers.Timer checkForTime = new System.Timers.Timer(interval60Minutes);
            checkForTime.Elapsed += new ElapsedEventHandler(checkForTime_Elapsed);
            checkForTime.Enabled = true;



            // Save any state changes that might have occured during the turn.
            await _conversationState.SaveChangesAsync(turnContext, false, cancellationToken);
            await _userState.SaveChangesAsync(turnContext, false, cancellationToken);

        }

        protected override async Task OnMessageActivityAsync(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
     
            var input = turnContext.Activity.Text;
            var luisResponse = await LuisService.ParseUserInput(input);

            var replyMessage = string.Empty;
            var replyMessage2 = string.Empty; //for similar tickets which exceed 3
            var intent = "";

            for (int i = 0; i < luisResponse.entities.Length; i++)
            {
                if (luisResponse.entities[i].type == "Location")
                {
                    currIntent = "countEventPerAppAtLocation";
                    intent = "countEventPerAppAtLocation";
                    luisResponse.topScoringIntent.intent = "countEventPerAppAtLocation";
                    break;
                }
            }

           

            //category
           

            //to add more than 1 submenu at one time
            if (accessRequestTriggeredOnce == true)
            {
                for (int i = 0; i < Cards.menuSubmenu.Count(); i++)
                {
                    if (input == Cards.menuSubmenu[i].Value)
                    {
                        currIntent = "addMoreMenu2";
                        luisResponse.topScoringIntent.intent = "choice";
                        recordSubmenu = true;
                        selectMoreSubmenu = true;
                    }
                    else if (input == Cards.menuSubmenu[i].Key)
                    {
                        triggerSubmenu = true;
                    }
                }
            }

            if (currIntent == "addMoreMenu2" && luisResponse.topScoringIntent.intent == "choice")
            {
                currIntent = "AccessRequest";
                if (input == "Yes")
                {
                    input = "No";
                    luisResponse.topScoringIntent.intent = "choice";
                    startAccessRequestFlow = true;
                    countAccessRequest = 2;
                }
                //if user chooses not to add more menu
                else
                {
                    currIntent = "asdfghj";
                    luisResponse.topScoringIntent.intent = "declineMoreMenu";
                    startAccessRequestFlow = false;
                    countAccessRequest = 0;
                    accessRequestTriggeredOnce = false;
                    replyMessage = "Thank you! Once the ticket is executed, the support team will notify you.";
                }

            }

            if (startAccessRequestFlow == true && luisResponse.topScoringIntent.intent != "choice")
            {
                luisResponse.topScoringIntent.intent = "AccessRequest";
            }
            //new
            if (recordSubmenu == true)
            {
                menuandsubmenu += "|" + input;
                submenu = input;
                recordSubmenu = false;
                accessRequestTriggeredOnce = true;
                luisResponse.topScoringIntent.intent = "choice";
                currIntent = "addMoreMenu";
                string fileName = @"C:\Users\diksha.cuniah\source\repos\EchoBotFinal\EchoBotFinal\Resources\MenuList.txt";
                FileInfo file = new FileInfo(fileName);
                startAccessRequestFlow = false;

                try
                {
                    var userExists = false;
                    // Check if file already exists. If yes, append it.     
                    if (file.Exists)
                    {
                        var lineNum = -1;
                        List<string> quotelist = File.ReadAllLines(fileName).ToList();
                        for (int i = 0; i < quotelist.Count(); i++)
                        {
                            string[] arr = quotelist[i].Split(":");
                            if (arr[0] == requestedUser)
                            {
                                userExists = true;
                                lineNum = i;
                            }
                        }
                        if (lineNum >= 0)
                        {
                            string lineToRemove = quotelist[lineNum];
                            quotelist.RemoveAt(lineNum);
                            File.WriteAllLines(fileName, quotelist.ToArray());
                            string[] startOfSubmenu = submenu.Split("_");
                            if (startOfSubmenu[0] != menu)
                            {
                                menu = startOfSubmenu[0];
                            }
                            using (var tw = new StreamWriter(fileName, true))
                            {
                                tw.WriteLine(lineToRemove + "/" + menu + "|" + submenu);
                            }
                        }

                        else
                        {
                            if (userExists == false)
                            {
                                using (var tw = new StreamWriter(fileName, true))
                                {
                                    tw.WriteLine(requestedUser + ":" + menu + "|" + submenu);
                                }
                            }
                        }
                    }
                    else
                    {
                        // Create a new file     
                        using (StreamWriter sw = file.CreateText())
                        {
                            sw.WriteLine(requestedUser + ":" + menuandsubmenu);
                        }
                    }
                    countAccessRequest = 0;
                }
                catch (Exception Ex)
                {
                    Console.WriteLine(Ex.ToString());
                }
            }

            if (triggerSubmenu == true)
            {
                luisResponse.topScoringIntent.intent = "triggerSubmenu";
                triggerSubmenu = false;
                menuandsubmenu = input;
                menu = input;
                recordSubmenu = true;
            }

          

            //for notification when ticket changes state
           
            if (luisResponse.intents.Count() > 0)
            {
                switch (luisResponse.topScoringIntent.intent) //take first intent which is top scoring intent
                {
                    
                    case "choice":
                       if (currIntent == "AccessRequest")
                        {
                            var lowerCaseInput = input.ToLower();
                            if (lowerCaseInput == "yes")
                            {
                                await turnContext.SendActivityAsync(MessageFactory.Text("Please give me the reference Id"), cancellationToken);
                                countAccessRequest++;
                                haveRefId = true;
                            }
                            else
                            {
                                //await turnContext.SendActivityAsync(MessageFactory.Text("Please select the Menu to be allocated to the user"), cancellationToken);
                                countAccessRequest++;
                                haveRefId = false;
                                name = "Norefid";
                                await SendSuggestedActionsAsync(turnContext, cancellationToken, name, currIntent);
                            }
                        }

                        else if (currIntent == "addMoreMenu")
                        {
                            await turnContext.SendActivityAsync(MessageFactory.Text("Thank you! The above information has been recorded."), cancellationToken);
                            await turnContext.SendActivityAsync(MessageFactory.Text("Do you want to add more menu?"), cancellationToken);
                            await SendSuggestedActionsAsync(turnContext, cancellationToken, name, "choice");
                            //change currIntent to change top scoring intent at top
                            currIntent = "addMoreMenu2";
                        }

                        //category
                        else
                        {
                            currIntent = "choice";
                            var text = turnContext.Activity.Text.ToLowerInvariant();
                            replyMessage = ProcessInput(text, name);
                        }
                        break;

                   
                    case "AccessRequest":
                        currIntent = "AccessRequest";

                        if (countAccessRequest == 0)
                        {
                            for (int i = 0; i < luisResponse.entities.Length; i++)
                            {
                                if (luisResponse.entities[i].type == "appName")
                                {
                                    appname = luisResponse.entities[i].entity;
                                    name = appname;
                                }
                            }
                            countAccessRequest++;
                            startAccessRequestFlow = true;
                            await turnContext.SendActivityAsync(MessageFactory.Text("Please enter the ID of the user requesting the access"), cancellationToken);
                        }

                        else if (countAccessRequest == 1)
                        {
                            requestedUser = input;
                            countAccessRequest++;
                            await turnContext.SendActivityAsync(MessageFactory.Text("Please enter the site "), cancellationToken);
                        }

                        else if (countAccessRequest == 2)
                        { 
                            name = "AccessRequestChoice";
                            site = input;
                            await SendSuggestedActionsAsync(turnContext, cancellationToken, name, currIntent);
                        }

                        else if (countAccessRequest == 3)
                        {
                            if (haveRefId == true)
                            {
                                refId = input;
                                await turnContext.SendActivityAsync(MessageFactory.Text("Thank you! A ticket is being created using the above information on Service Now." + Environment.NewLine + "We will communicate to you soon the ticket number,once the ticket is executed, the support team will notify you."), cancellationToken);
                                countAccessRequest = 0;
                                startAccessRequestFlow = false;
                            }
                            else
                            {
                                //await turnContext.SendActivityAsync(MessageFactory.Text("Please select the menu to be allocated to the user: "), cancellationToken);
                                name = appname;
                                await SendSuggestedActionsAsync(turnContext, cancellationToken, name, currIntent);
                            }
                        }
                        break;

                    case "triggerSubmenu":
                        currIntent = "triggerSubmenu";
                        name = input;
                        await SendSuggestedActionsAsync(turnContext, cancellationToken, name, currIntent);
                        break;

                    
                    case "declineMoreMenu":

                        break;

                        //category

                    

                }
            }

            else
            {
                replyMessage = "no matching intent";
            }

           if (currIntent == "countEventByAssigned")
            {

            }

            else if (currIntent == "AvgDuration")
            {

            }

            else if (currIntent == "AccessRequest")
            {

            }

            else if (currIntent == "countEventByTime")
            {

            }

            else if (currIntent == "countEventPerAppAtLocation")
            {

            }

            else if (currIntent == "addMoreMenu2")
            {

            }
            else if (currIntent == "solvedOrNot")
            {

            }
            else if (currIntent == "appIssue")
            { }

           
          

          
            else
            {
                await turnContext.SendActivityAsync(MessageFactory.Text(replyMessage), cancellationToken);
            }
        }


       
       

        protected override async Task OnMembersAddedAsync(IList<ChannelAccount> membersAdded, ITurnContext<IConversationUpdateActivity> turnContext, CancellationToken cancellationToken)
        {
          
            foreach (var member in membersAdded)
            {
                if (member.Id != turnContext.Activity.Recipient.Id)
                {
                    await turnContext.SendActivityAsync(MessageFactory.Text($"Hello!" + Environment.NewLine + $"Trust you are well" + Environment.NewLine + $"Hope that you are having a good day" + Environment.NewLine + $"We are contacting you concerning lea access requests" + Environment.NewLine + $"Could you please review the following tasks if any and add the required information!"), cancellationToken);
                    //await turnContext.SendActivityAsync(MessageFactory.Text($"Please type ok to continue!"), cancellationToken);
                    await turnContext.SendActivityAsync(MessageFactory.Text("Could you please click on the below button to continue?"));

                    var card = new HeroCard
                    {
                        //Text = "Could you please click on the below button to continue?",
                        Buttons = new List<CardAction>
                        {
                            new CardAction(ActionTypes.ImBack, title: "lea access request", value: "lea access request"),
                        },
                    };
                    var reply = MessageFactory.Attachment(card.ToAttachment());
                    await turnContext.SendActivityAsync(reply, cancellationToken);


                    System.Timers.Timer checkForTime = new System.Timers.Timer(interval60Minutes);
                    checkForTime.Elapsed += new ElapsedEventHandler(checkForTime_Elapsed);
                    checkForTime.Enabled = true;

                    //shay
                    System.Timers.Timer checkForTime2 = new System.Timers.Timer(interval60Minutes2);
                    //checkForTime2.Elapsed += new ElapsedEventHandler(checkForTime_Elapsed2);
                    checkForTime2.Enabled = true;

                    countAccessRequest = 0;
                    Cards.addToList();
                    accessRequestTriggeredOnce = false;
                    startAccessRequestFlow = false;
                    triggerSubmenu = false;
                    recordSubmenu = false;
                    selectMoreSubmenu = false;
                    currIntent = "";
                    timeNotSpecified = false;
                    specifyTicketNumForStateChange = false;
                }
            }

        }
        void checkForTime_Elapsed(object sender, ElapsedEventArgs e)
        {
            bool timeIsReady = true;
            if (timeIsReady == true)
            {
                var url = "http://localhost:3978/api/notify";

                try
                {
                    Process.Start(url);
                }
                catch
                {
                    // hack because of this: https://github.com/dotnet/corefx/issues/10361
                    if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                    {
                        url = url.Replace("&", "^&");
                        Process.Start(new ProcessStartInfo("cmd", $"/c start {url}") { CreateNoWindow = false });
                    }
                    else if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
                    {
                        Process.Start("xdg-open", url);
                    }
                    else if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
                    {
                        Process.Start("open", url);
                    }
                    else
                    {
                        throw;
                    }
                }
            }
        }

        

        private int TimerTrigger(string v)
        {
            throw new NotImplementedException();
        }

        private static string ProcessInput(string text, string name)
        {
            switch (text)
            {
                case "yes":
                    {

                        return "You have booked a meeting with " + name;
                    }

                case "no":
                    {
                        return "You declined";
                    }

                default:
                    {
                        return "Please select an answer from the suggested action choices";
                    }
            }
        }

        private async Task SendSuggestedActionsAsync(ITurnContext turnContext, CancellationToken cancellationToken, string name, string intent)
        {
            switch (intent)
            {

                case "ticketStatus":


                case "choice":
                    var rply = MessageFactory.Text("");

                    rply.SuggestedActions = new SuggestedActions()
                    {
                        Actions = new List<CardAction>()
                        {
                            new CardAction() { Title = "Yes", Type = ActionTypes.ImBack, Value = "Yes" },
                            new CardAction() { Title = "No", Type = ActionTypes.ImBack, Value = "No" },
                        },
                    };
                    await turnContext.SendActivityAsync(rply, cancellationToken);
                    break;

   
                case "AccessRequest":
                    if (name == "AccessRequestChoice")
                    {
                        var arply = MessageFactory.Text("Do you have a reference ID?");

                        arply.SuggestedActions = new SuggestedActions()
                        {
                            Actions = new List<CardAction>()
                        {
                            new CardAction() { Title = "Yes", Type = ActionTypes.ImBack, Value = "Yes" },
                            new CardAction() { Title = "No", Type = ActionTypes.ImBack, Value = "No" },
                        },
                        };
                        await turnContext.SendActivityAsync(arply, cancellationToken);
                        break;
                    }
                    else
                    {
                        var attachmentsAccessMenus = new List<Attachment>();
                        var replyAccessRequest = MessageFactory.Attachment(attachmentsAccessMenus);
                        replyAccessRequest.Attachments.Add(EchoBotFinal.Bots.Cards.GetAccessRequestMenuList(name).ToAttachment());
                        await turnContext.SendActivityAsync(replyAccessRequest, cancellationToken);
                    }
                    break;

                case "triggerSubmenu":
                    var attachmentsSubmenu = new List<Attachment>();
                    var replySubmenu = MessageFactory.Attachment(attachmentsSubmenu);
                    replySubmenu.Attachments.Add(EchoBotFinal.Bots.Cards.GetAccessRequestSubMenuList(name).ToAttachment());
                    await turnContext.SendActivityAsync(replySubmenu, cancellationToken);
                    break;
            }
        }
    }
}
