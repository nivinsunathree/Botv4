// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
//
// Generated with Bot Builder V4 SDK Template for Visual Studio EchoBot v4.3.0

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using EchoBotFinal.Models;
using EchoBotFinal.Service;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Activity = Microsoft.Bot.Schema.Activity;
using System.Net.Mail;
using Attachment = Microsoft.Bot.Schema.Attachment;
using System.Net;
using System.Text;

namespace EchoBotFinal.Bots
{
    public class EchoBot : ActivityHandler
    {
        public static string searchQuery = "";
        public static string ticketNumberThatClosed = "";
        const double interval60Minutes2 = 5 * 1000; //for state change



        const double interval60Minutes = 5 * 1000; // for new tickets arriving
        static string name;
        static string name2;
        static string currIntent;
        static SplunkItem currSplunkItem;
        static bool startCommentResult = false;
        static int countComment = 0;
        static List<KeyValuePair<string, string>> dailyReportingList = new List<KeyValuePair<string, string>>();
        static bool startAccessRequestFlow = false;
        static int countAccessRequest = 0;
        static bool haveRefId = false;
        public static bool triggerSubmenu = false;
        static string menuandsubmenu;
        static string menu;
        static string submenu;
        public static bool recordSubmenu = false;
        static bool accessRequestTriggeredOnce = false;
        static bool selectMoreSubmenu = false;
        static bool timeNotSpecified = false;
        static bool specifyTicketNumForStateChange = false;
        

        //for file menu submenu recording
        static string appname = "";
        static string requestedUser = "";
        static string site = "";
        static string refId = "";

        //for notification
        public static List<KeyValuePair<string, string>> savedSearchesList = new List<KeyValuePair<string, string>>();

        //shay
        static bool descriptionGiven = false;
        static bool askforAppName = false;
        static bool askForErrorMsg = false;
        static bool askForDocSummary = false;
        static bool categoryOfIssues = false;
        static bool AppName = false;
        static bool addToList = false;

        //proactivebot
        private ConcurrentDictionary<string, ConversationReference> _conversationReferences;

        public EchoBot(ConcurrentDictionary<string, ConversationReference> conversationReferences)
        {
            _conversationReferences = conversationReferences;
        }

        private void AddConversationReference(Activity activity)
        {
            var conversationReference = activity.GetConversationReference();
            _conversationReferences.AddOrUpdate(conversationReference.User.Id, conversationReference, (key, newValue) => conversationReference);
        }

        protected override Task OnConversationUpdateActivityAsync(ITurnContext<IConversationUpdateActivity> turnContext, CancellationToken cancellationToken)
        {
            AddConversationReference(turnContext.Activity as Activity);

            return base.OnConversationUpdateActivityAsync(turnContext, cancellationToken);
        }

        protected override async Task OnMessageActivityAsync(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            var input = turnContext.Activity.Text;
            var splunkItem = new SplunkItem();

            var luisResponse = await LuisService.ParseUserInput(input);

            var replyMessage = string.Empty;
            var replyMessage2 = string.Empty; //for similar tickets which exceed 3
            var intent = "";

            
            //to add more than 1 submenu at one time
            if (accessRequestTriggeredOnce == true)
            {
                for (int i = 0; i < Cards.menuSubmenu.Count(); i++)
                {
                    if (input == Cards.menuSubmenu[i].Value)
                    {
                        currIntent = "addMoreMenu2";
                        luisResponse.topScoringIntent.intent = "choice";
                        recordSubmenu = true;
                        selectMoreSubmenu = true;
                    }
                    else if (input == Cards.menuSubmenu[i].Key)
                    {
                        triggerSubmenu = true;
                    }
                }
            }

            if (currIntent == "addMoreMenu2" && luisResponse.topScoringIntent.intent == "choice")
            {
                currIntent = "AccessRequest";
                if (input == "Yes")
                {
                    input = "No";
                    luisResponse.topScoringIntent.intent = "choice";
                    startAccessRequestFlow = true;
                    countAccessRequest = 2;
                }
                //if user chooses not to add more menu
                else
                {
                    currIntent = "asdfghj";
                    luisResponse.topScoringIntent.intent = "declineMoreMenu";
                    startAccessRequestFlow = false;
                    countAccessRequest = 0;
                    accessRequestTriggeredOnce = false;
                    replyMessage = "Thank you! Once the ticket is executed, the support team will notify you.";
                }

            }

            if (startAccessRequestFlow == true && luisResponse.topScoringIntent.intent != "choice")
            {
                luisResponse.topScoringIntent.intent = "AccessRequest";
            }
            //new
            if (recordSubmenu == true)
            {
                menuandsubmenu += "|" + input;
                submenu = input;
                recordSubmenu = false;
                accessRequestTriggeredOnce = true;
                luisResponse.topScoringIntent.intent = "choice";
                currIntent = "addMoreMenu";
                string fileName = @"C:\Users\diksha.cuniah\source\repos\EchoBotFinal\EchoBotFinal\Resources\MenuList.txt";
                FileInfo file = new FileInfo(fileName);
                startAccessRequestFlow = false;

                try
                {
                    var userExists = false;
                    // Check if file already exists. If yes, append it.     
                    if (file.Exists)
                    {
                        var lineNum = -1;
                        List<string> quotelist = File.ReadAllLines(fileName).ToList();
                        for (int i = 0; i < quotelist.Count(); i++)
                        {
                            string[] arr = quotelist[i].Split(":");
                            if (arr[0] == requestedUser)
                            {
                                userExists = true;
                                lineNum = i;
                            }
                        }
                        if (lineNum >= 0)
                        {
                            string lineToRemove = quotelist[lineNum];
                            quotelist.RemoveAt(lineNum);
                            File.WriteAllLines(fileName, quotelist.ToArray());
                            string[] startOfSubmenu = submenu.Split("_");
                            if (startOfSubmenu[0] != menu)
                            {
                                menu = startOfSubmenu[0];
                            }
                            using (var tw = new StreamWriter(fileName, true))
                            {
                                tw.WriteLine(lineToRemove + "/" + menu + "|" + submenu);
                            }
                        }

                        else
                        {
                            if (userExists == false)
                            {
                                using (var tw = new StreamWriter(fileName, true))
                                {
                                    tw.WriteLine(requestedUser + ":" + menu + "|" + submenu);
                                }
                            }
                        }
                    }
                    else
                    {
                        // Create a new file     
                        using (StreamWriter sw = file.CreateText())
                        {
                            sw.WriteLine(requestedUser + ":" + menuandsubmenu);
                        }
                    }
                    countAccessRequest = 0;
                }
                catch (Exception Ex)
                {
                    Console.WriteLine(Ex.ToString());
                }
            }

            if (triggerSubmenu == true)
            {
                luisResponse.topScoringIntent.intent = "triggerSubmenu";
                triggerSubmenu = false;
                menuandsubmenu = input;
                menu = input;
                recordSubmenu = true;
            }


            if (luisResponse.intents.Count() > 0)
            {
                switch (luisResponse.topScoringIntent.intent) //take first intent which is top scoring intent
                {
                   
                    case "choice":
                        if (currIntent == "AccessRequest")
                        {
                            var lowerCaseInput = input.ToLower();
                            if (lowerCaseInput == "yes")
                            {
                                await turnContext.SendActivityAsync(MessageFactory.Text("Please give me the reference Id"), cancellationToken);
                                countAccessRequest++;
                                haveRefId = true;
                            }
                            else
                            {
                                //await turnContext.SendActivityAsync(MessageFactory.Text("Please select the Menu to be allocated to the user"), cancellationToken);
                                countAccessRequest++;
                                haveRefId = false;
                                name = "Norefid";
                                await SendSuggestedActionsAsync(turnContext, cancellationToken, name, currIntent);
                            }
                        }

                        else if(currIntent == "addMoreMenu")
                        {
                            await turnContext.SendActivityAsync(MessageFactory.Text("Thank you! The above information has been recorded."), cancellationToken);
                            await turnContext.SendActivityAsync(MessageFactory.Text("Do you want to add more menu?"), cancellationToken);
                            await SendSuggestedActionsAsync(turnContext, cancellationToken, name, "choice");
                            //change currIntent to change top scoring intent at top
                            currIntent = "addMoreMenu2";
                        }

                        //category
                        
                        break;

                   

                    case "AccessRequest":
                        currIntent = "AccessRequest";

                        if (countAccessRequest == 0)
                        {
                            for (int i = 0; i < luisResponse.entities.Length; i++)
                            {
                                if (luisResponse.entities[i].type == "appName")
                                {
                                    appname = luisResponse.entities[i].entity;
                                    name = appname;
                                }
                            }
                            countAccessRequest++;
                            startAccessRequestFlow = true;
                            await turnContext.SendActivityAsync(MessageFactory.Text("Please enter the ID of the user requesting the access"), cancellationToken);
                        }

                        else if (countAccessRequest == 1)
                        {
                            requestedUser = input;
                            countAccessRequest++;
                            await turnContext.SendActivityAsync(MessageFactory.Text("Please enter the site "), cancellationToken);
                        }

                        else if (countAccessRequest == 2)
                        { 
                            name = "AccessRequestChoice";
                            site = input;
                            await SendSuggestedActionsAsync(turnContext, cancellationToken, name, currIntent);
                        }

                        else if (countAccessRequest == 3)
                        {
                            if (haveRefId == true)
                            {
                                refId = input;
                                await turnContext.SendActivityAsync(MessageFactory.Text("Thank you! A ticket is being created using the above information on Service Now." + Environment.NewLine + "We will communicate to you soon the ticket number,once the ticket is executed, the support team will notify you."), cancellationToken);
                                countAccessRequest = 0;
                                startAccessRequestFlow = false;
                            }
                            else
                            {
                                //await turnContext.SendActivityAsync(MessageFactory.Text("Please select the menu to be allocated to the user: "), cancellationToken);
                                name = appname;
                                await SendSuggestedActionsAsync(turnContext, cancellationToken, name, currIntent);
                            }
                        }
                        break;

                    case "triggerSubmenu":
                        currIntent = "triggerSubmenu";
                        name = input;
                        await SendSuggestedActionsAsync(turnContext, cancellationToken, name, currIntent);
                        break;

                    
                    case "declineMoreMenu":

                        break;

                        //category

                    

                }
            }

            else
            {
                replyMessage = "no matching intent";
            }

            if (currIntent == "countEventByAssigned")
            {

            }

            else if (currIntent == "AvgDuration")
            {

            }

            else if (currIntent == "AccessRequest")
            {

            }

            else if (currIntent == "countEventByTime")
            {

            }

            else if (currIntent == "countEventPerAppAtLocation")
            {

            }

            else if (currIntent == "addMoreMenu2")
            {

            }
            else if (currIntent == "solvedOrNot")
            {

            }
            else if (currIntent == "appIssue")
            { }

           

            else
            {
                await turnContext.SendActivityAsync(MessageFactory.Text(replyMessage), cancellationToken);
            }
        }


        private async Task<SplunkItem> GetSplunkDetails(string intent, string entity)
        {

            var splunkItem = await SplunkService.GetSplunkInfo(intent, entity,"");
            currSplunkItem = splunkItem;
            return splunkItem;
        }

        private async Task<string> GetSplunk(string intent, string entity)
        {
            SplunkItem splunkItem = await SplunkService.GetSplunkInfo(intent, entity,"");
            string returnValue = "x";
            currSplunkItem = splunkItem;
            //string[] dataList=new string[16];
            if (splunkItem.Status == "FAIL")
            {
                returnValue = "Splunk Error";
            }

            else
            {
                if (intent == "ticketStatus")
                {
                    string workNotes = splunkItem.results[0].fWorknotes;
                    var regex = new Regex(@"\d{4} *\- *\d{2} *\- *\d{2} \d{2}:\d{2}:\d{2}");
                    List<DateTime> list = new List<DateTime>();
                    int index = 0;
                    foreach (Match m in regex.Matches(workNotes))
                    {
                        DateTime dt = Convert.ToDateTime(m.Value);
                        index = m.Index;
                        list.Add(dt);
                    }
                    name = splunkItem.results[0].assignedto;
                    name2 = splunkItem.results[0].assignedto;
                    String shortenedWorkNotes = workNotes.Substring(index);

                    var rex = new Regex(@"\[code\]");

                    foreach (Match m in rex.Matches(shortenedWorkNotes))
                    {
                        if (m != null)
                        {
                            index = m.Index;
                            shortenedWorkNotes = shortenedWorkNotes.Substring(0, (index));
                        }
                    }

                    returnValue = "Ticket Number: " + currSplunkItem.results[0].ticketnumber + Environment.NewLine + "Short Description: " + splunkItem.results[0].short_description + Environment.NewLine + "Priority: " + splunkItem.results[0].priority + Environment.NewLine + "Business Service: " + splunkItem.results[0].fapplication + Environment.NewLine + "Status: " + splunkItem.results[0].state + Environment.NewLine + "Assignment group: " + splunkItem.results[0].assignmentgroup + Environment.NewLine + "Assigned to: " + splunkItem.results[0].assignedto + Environment.NewLine + "Latest Work Notes: " + shortenedWorkNotes;
                    currSplunkItem = splunkItem;
                    if (string.Equals(splunkItem.results[0].state, "Closed", StringComparison.CurrentCultureIgnoreCase) || string.Equals(splunkItem.results[0].state, "Resolved", StringComparison.CurrentCultureIgnoreCase))
                    {
                        //name = splunkItem.results[0].Number;
                        //currSplunkItem = splunkItem;
                        returnValue += Environment.NewLine + "Resolution Notes: " + splunkItem.results[0].fResolutionnotes;
                    }

                }
            }
            return returnValue;
        }

        protected override async Task OnMembersAddedAsync(IList<ChannelAccount> membersAdded, ITurnContext<IConversationUpdateActivity> turnContext, CancellationToken cancellationToken)
        {
            foreach (var member in membersAdded)
            {
                if (member.Id != turnContext.Activity.Recipient.Id)
                {
                    await turnContext.SendActivityAsync(MessageFactory.Text($"Hello!" + Environment.NewLine + $"Trust you are well" + Environment.NewLine + $"Hope that you are having a good day" + Environment.NewLine + $"We are contacting you concerning lea access requests" + Environment.NewLine + $"Could you please review the following tasks if any and add the required information!"), cancellationToken);
                    //await turnContext.SendActivityAsync(MessageFactory.Text($"Please type ok to continue!"), cancellationToken);
                    await turnContext.SendActivityAsync(MessageFactory.Text("Could you please click on the below button to continue?"));

                    var card = new HeroCard
                    {
                        //Text = "Could you please click on the below button to continue?",
                        Buttons = new List<CardAction>
                        {
                            new CardAction(ActionTypes.ImBack, title: "lea access request", value: "lea access request"),
                        },
                    };
                    var reply = MessageFactory.Attachment(card.ToAttachment());
                    await turnContext.SendActivityAsync(reply, cancellationToken);

                    System.Timers.Timer checkForTime = new System.Timers.Timer(interval60Minutes);
                    checkForTime.Elapsed += new ElapsedEventHandler(checkForTime_Elapsed);
                    checkForTime.Enabled = true;

                    //shay
                    System.Timers.Timer checkForTime2 = new System.Timers.Timer(interval60Minutes2);
                    //checkForTime2.Elapsed += new ElapsedEventHandler(checkForTime_Elapsed2);
                    checkForTime2.Enabled = true;

                    countAccessRequest = 0;
                    Cards.addToList();
                    accessRequestTriggeredOnce = false;
                    startAccessRequestFlow = false;
                    triggerSubmenu = false;
                    recordSubmenu = false;
                    selectMoreSubmenu = false;
                    currIntent = "";
                    timeNotSpecified = false;
                    specifyTicketNumForStateChange = false;
                }
            }

        }
        void checkForTime_Elapsed(object sender, ElapsedEventArgs e)
        {
            bool timeIsReady = true;
            if (timeIsReady == true)
            {
                var url = "http://localhost:3978/api/notify";

                try
                {
                    Process.Start(url);
                }
                catch
                {
                    // hack because of this: https://github.com/dotnet/corefx/issues/10361
                    if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                    {
                        url = url.Replace("&", "^&");
                        Process.Start(new ProcessStartInfo("cmd", $"/c start {url}") { CreateNoWindow = false });
                    }
                    else if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
                    {
                        Process.Start("xdg-open", url);
                    }
                    else if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
                    {
                        Process.Start("open", url);
                    }
                    else
                    {
                        throw;
                    }
                }
            }
        }

        

        private int TimerTrigger(string v)
        {
            throw new NotImplementedException();
        }

        private static string ProcessInput(string text, string name)
        {
            switch (text)
            {
                case "yes":
                    {

                        return "You have booked a meeting with " + name;
                    }

                case "no":
                    {
                        return "You declined";
                    }

                default:
                    {
                        return "Please select an answer from the suggested action choices";
                    }
            }
        }

        private async Task SendSuggestedActionsAsync(ITurnContext turnContext, CancellationToken cancellationToken, string name, string intent)
        {
            switch (intent)
            {

                case "ticketStatus":

                    if (name == "InProgress")
                    {
                        var reply = MessageFactory.Text("Does the ticket require immediate attention?");

                        reply.SuggestedActions = new SuggestedActions()
                        {
                            Actions = new List<CardAction>()
                        {
                            new CardAction() { Title = "Yes", Type = ActionTypes.ImBack, Value = "Yes" },
                            new CardAction() { Title = "No", Type = ActionTypes.ImBack, Value = "No" },
                        },
                        };
                        await turnContext.SendActivityAsync(reply, cancellationToken);
                    }

                    else
                    {
                        var reply = MessageFactory.Text("Do you want to schedule a meeting with " + name);

                        reply.SuggestedActions = new SuggestedActions()
                        {
                            Actions = new List<CardAction>()
                        {
                            new CardAction() { Title = "Yes", Type = ActionTypes.ImBack, Value = "Yes" },
                            new CardAction() { Title = "No", Type = ActionTypes.ImBack, Value = "No" },
                        },
                        };
                        await turnContext.SendActivityAsync(reply, cancellationToken);
                    }
                    break;


                case "relatedTicketInfo":
                    var reply6 = MessageFactory.Text("");

                    reply6.SuggestedActions = new SuggestedActions()
                    {
                        Actions = new List<CardAction>()
                        {
                            new CardAction() { Title = "Yes", Type = ActionTypes.ImBack, Value = "Yes" },
                            new CardAction() { Title = "No", Type = ActionTypes.ImBack, Value = "No" },
                        },
                    };
                    await turnContext.SendActivityAsync(reply6, cancellationToken);
                    break;

                case "choice":
                    var rply = MessageFactory.Text("");

                    rply.SuggestedActions = new SuggestedActions()
                    {
                        Actions = new List<CardAction>()
                        {
                            new CardAction() { Title = "Yes", Type = ActionTypes.ImBack, Value = "Yes" },
                            new CardAction() { Title = "No", Type = ActionTypes.ImBack, Value = "No" },
                        },
                    };
                    await turnContext.SendActivityAsync(rply, cancellationToken);
                    break;

                case "None":
                    var splunkItem = await GetSplunkDetails("similarTicketsAsInput", name);

                    if (splunkItem.results != null)
                    {
                        var attachments2 = new List<Attachment>();

                        var replyhc2 = MessageFactory.Attachment(attachments2);

                        replyhc2.Attachments.Add(EchoBotFinal.Bots.Cards.GetHeroCard(splunkItem).ToAttachment());

                        await turnContext.SendActivityAsync(replyhc2, cancellationToken);
                    }

                    else
                    {
                        await turnContext.SendActivityAsync(MessageFactory.Text("Please enter correct ticket number!"), cancellationToken);
                    }
                    break;

                case "countEventByAssigned":
                    string[] assignedTo = { "Ashwina Sujeeun FP11818", "Aswan Boyjoo FP18010", "Avneesh - Kumar Torul FP11657", "Manisha Kora-Ramiah FP11586", "Marie - Carol - Virginie Bongout FP11877", "Niven Bulramaya FP11478", "Sephali Ramdoss FP11477", "Service - ITSM Ibm - icd Service - ITSM.IBM - ICD", "Sharvind Bulleeram FP11699", "Sunthbocus Ridwan FP11558", "Suryadev Sunathree FP11871", "Thomas Moldoch FP11643" };
                    var reply3 = MessageFactory.Text("Did you mean?");
                    string x = "default";

                    foreach (string w in assignedTo)
                    {
                        if (w.Substring(0, 1).Equals(name, StringComparison.InvariantCultureIgnoreCase))
                        {
                            x = w;
                        }
                    }

                    reply3.SuggestedActions = new SuggestedActions()
                    {
                        Actions = new List<CardAction>()
                        {
                            new CardAction() {
                                Title = x, Type = ActionTypes.ImBack, Value = x
                            },
                        },
                    };
                    await turnContext.SendActivityAsync(reply3, cancellationToken);
                    break;

                case "countEventByApp":

                    string[] apps = { "FYT - FYT/LOGIN - Flow and Traceability", "GP2 - Plant Master Production Planning M", "IQA - Architecture Quality Information", "PDO - Plant data warehouse for operation", "LEA - LEA - AirCraft line product tyre con", "FDM - Enterprise Federated Datamart", "OEE - OVERALL EFFICIENCY EQUIPEMENT", "FAO - DGSI / PS / EP KPI solution", "FOA - Follow - up of Operator Activity", "GRQ - GRQ2 - Quality Results Management fo", "ACO - MARCO : Michelin Architecture Cont", "YRS - Reporting TRS Standard OAQ10", "EGQ - EGQM - analysis of GRQ2 data", "FIM - GC Final inspection management", "MOM - MMRP - Motor MRP", "GAZ - GAMZ - Management of production Z", "ZRM - ZSRM - Folow - up of mixture results -", "ZGM - ZGFM - Management of the mixture car", "BSM - Stock Management System", "KBT - Kanban need transport preparation", "AGA - AGATE - Management of production(", "CCS - Calculation of machine loads - Ca", "IPA - Computerization of the workshop pi", "ZQL - ZQPL - balance sheetquality - Bilan", "ACS - ACSA - Forklift call and advanced", "MSZ - Recyclage des chutes", "BF1 - BF1 - ETC traceability database", "ZBB - ZBASE - Referential calendar - R�f�r", "RTZ - R�sultats Traitements Z", "BMA - Master App for maintenance and spa", "BMO - Base of ordering of the moulds - B", "T2R - Transfer Transform and Routing", "MBI - Maintenance Business Intelligence", "P2M - Production Process Model / Referen", "MR2 - MyPlan Reports", "PF2 - PFR_PILOTAGE FLUX RECHAPAGE BDR", "SFR - MATRM Manufacturing Follow up - Suiv", "FIF - FIFO - SF Warehouse managment", "DFR - DATA FOR R +", "CIA - Contr�leur Intranet d'Applications", "LEI - LEI Hyperion for Aircraft Line produ", "CDO - Central Datawarehouse for Operatio", "OCF - Consolidation of OEE data", "M2T - Motorsport Tyres Tracability" };

                    var reply4 = MessageFactory.Text("Did you mean?");
                    string ans = "default";
                    int count = 0;
                    string y = "default";
                    var attachmentsApp = new List<Attachment>();
                    var replyhcApp = MessageFactory.Attachment(attachmentsApp);
                    List<string> matchedApp = new List<string>();
                    foreach (string w in apps)
                    {
                        if (w.Substring(0, 1).Equals(name, StringComparison.InvariantCultureIgnoreCase))
                        {
                            matchedApp.Add(w);
                        }
                    }

                    replyhcApp.Attachments.Add(EchoBotFinal.Bots.Cards.GetSimilarAppName(matchedApp).ToAttachment());
                    await turnContext.SendActivityAsync(replyhcApp, cancellationToken);
                    break;

                case "FurtherQuestionTicketStatus":
                    var reply5 = MessageFactory.Text("Can i assist you further?");
                    var attachments = new List<Attachment>();
                    var replyhc = MessageFactory.Attachment(attachments);
                    replyhc.Attachments.Add(EchoBotFinal.Bots.Cards.GetSimilarQuestionsTicketStatus(currSplunkItem.results[0].ticketnumber, currSplunkItem).ToAttachment());
                    await turnContext.SendActivityAsync(replyhc, cancellationToken);
                    break;

                case "AskSimilarQuestionByApp":
                    var reply7 = MessageFactory.Text("Can i assist you further?");
                    var attachmentsAppQuestions = new List<Attachment>();
                    var replyAppQuest = MessageFactory.Attachment(attachmentsAppQuestions);
                    replyAppQuest.Attachments.Add(EchoBotFinal.Bots.Cards.GetSimilarQuestionsPerApplication(name).ToAttachment());
                    await turnContext.SendActivityAsync(replyAppQuest, cancellationToken);
                    break;

                case "AccessRequest":
                    if (name == "AccessRequestChoice")
                    {
                        var arply = MessageFactory.Text("Do you have a reference ID?");

                        arply.SuggestedActions = new SuggestedActions()
                        {
                            Actions = new List<CardAction>()
                        {
                            new CardAction() { Title = "Yes", Type = ActionTypes.ImBack, Value = "Yes" },
                            new CardAction() { Title = "No", Type = ActionTypes.ImBack, Value = "No" },
                        },
                        };
                        await turnContext.SendActivityAsync(arply, cancellationToken);
                        break;
                    }
                    else
                    {
                        var attachmentsAccessMenus = new List<Attachment>();
                        var replyAccessRequest = MessageFactory.Attachment(attachmentsAccessMenus);
                        replyAccessRequest.Attachments.Add(EchoBotFinal.Bots.Cards.GetAccessRequestMenuList(name).ToAttachment());
                        await turnContext.SendActivityAsync(replyAccessRequest, cancellationToken);
                    }
                    break;

                case "triggerSubmenu":
                    var attachmentsSubmenu = new List<Attachment>();
                    var replySubmenu = MessageFactory.Attachment(attachmentsSubmenu);
                    replySubmenu.Attachments.Add(EchoBotFinal.Bots.Cards.GetAccessRequestSubMenuList(name).ToAttachment());
                    await turnContext.SendActivityAsync(replySubmenu, cancellationToken);
                    break;
            }
        }
    }
}
