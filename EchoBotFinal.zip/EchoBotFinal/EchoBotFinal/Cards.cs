﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using Microsoft.Bot.Schema;
using Newtonsoft.Json;
using EchoBotFinal.Models;

namespace EchoBotFinal.Bots
{
    public static class Cards
    {
        public static List<KeyValuePair<string, string>> menuSubmenu = new List<KeyValuePair<string, string>>();
        public static Attachment CreateAdaptiveCardAttachment()
        {
            // combine path for cross platform support
            string[] paths = { ".", "Resources", "adaptiveCard.json" };
            var adaptiveCardJson = File.ReadAllText(Path.Combine(paths));

            var adaptiveCardAttachment = new Attachment()
            {
                ContentType = "application/vnd.microsoft.card.adaptive",
                Content = JsonConvert.DeserializeObject(adaptiveCardJson),
            };
            return adaptiveCardAttachment;
        }
       

        public static HeroCard GetSimilarAppName(List<string> name)
        {
            List<Object> attachments = new List<Object>();
            var heroCard = new HeroCard
            {
                Title = "Did you mean",
                Buttons = new List<CardAction> { }
            };

            for (int i = 0; i < name.Count; i++)
            {
                heroCard.Buttons.Add(new CardAction(ActionTypes.ImBack, name[i], value: name[i]));
                if (i >= 5)
                {
                    break;
                }

            }

            return heroCard;
        }

        public static HeroCard GetSimilarQuestionsPerApplication(string name)
        {
            List<Object> attachments = new List<Object>();
            var heroCard = new HeroCard
            {
                Title = "Can I assist you with the following?",
                Buttons = new List<CardAction> { new CardAction(ActionTypes.ImBack, "How many "+name+" tickets "+Environment.NewLine+" were assigned to each person", value: "How many "+name+" tickets were assigned to each person") ,
                new CardAction(ActionTypes.ImBack, "Average ticket duration for "+Environment.NewLine+name+" application", value: "Average ticket duration for "+name+" application") ,
                new CardAction(ActionTypes.ImBack, "Find number of tickets created in "+Environment.NewLine+name+" application this month", value: "Find number of tickets created in "+name+" application this month") },
            };

            return heroCard;
        }

        public static HeroCard GetAccessRequestMenuList(string name)
        {
            List<Object> attachments = new List<Object>();
            var heroCard = new HeroCard
            {
                Title = "Please select the menu to be allocated to the user",
                Buttons = new List<CardAction> { new CardAction(ActionTypes.ImBack, "Administration", value: "Administration") ,
                new CardAction(ActionTypes.ImBack, "Profil", value: "Profil") ,
                new CardAction(ActionTypes.ImBack, "Référentiel", value: "Référentiel"),
                new CardAction(ActionTypes.ImBack, "Référentiel BI", value: "Référentiel BI"),
                new CardAction(ActionTypes.ImBack, "Paramètre", value: "Paramètre"),
                new CardAction(ActionTypes.ImBack, "Gestion lot", value: "Gestion lot"),
                new CardAction(ActionTypes.ImBack, "Réception", value: "Réception"),
                new CardAction(ActionTypes.ImBack, "Vérification AVC", value: "Vérification AVC"),
                new CardAction(ActionTypes.ImBack, "Rechapage", value: "Rechapage"),
                new CardAction(ActionTypes.ImBack, "Vérification APC", value: "Vérification APC"),
                new CardAction(ActionTypes.ImBack, "Palettisation", value: "Palettisation"),
                new CardAction(ActionTypes.ImBack, "Libération", value: "Libération"),
                new CardAction(ActionTypes.ImBack, "'GEODE", value: "'GEODE"),
                new CardAction(ActionTypes.ImBack, "Qualité locale", value: "Qualité locale"),
                new CardAction(ActionTypes.ImBack, "Extraction", value: "Extraction")
                },


            };
            EchoBotFinal.Bots.EchoBot.triggerSubmenu = true;
            return heroCard;
        }

        public static void addToList() {
            if (menuSubmenu != null)
            {
                menuSubmenu.Add(new KeyValuePair<string, string>("Administration", "Administration_Utilisateur_Gestion profil"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Administration", "Administration_Multilingue"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Administration", "Administration_Log application"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Administration", "Administration_Log impression"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Profil", "Profil_Langue"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Profil", "Profil_Saisie marche degradee"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Profil", "Profil_Imprimantes"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Référentiel", "Referentiel_Imprimante_Creer"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Référentiel", "Referentiel_Imprimante_Rechercher"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Référentiel", "Referentiel_Utilisateur_Creer"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Référentiel", "Referentiel_Utilisateur_Rechercher"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Référentiel", "Referentiel_Codification SN_Creer"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Référentiel", "Referentiel_Codification SN_Rechercher"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Référentiel BI", "Referentiel BI_Utilisateur_Creer"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Référentiel BI", "Referentiel BI_Utilisateur_Rechercher"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Référentiel BI", "Referentiel BI_Utilisateur processus"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Paramètre", "Parametre_Etuve_Creer"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Paramètre", "Parametre_Etuve_Rechercher"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Paramètre", "Parametre_Machine_Creer"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Paramètre", "Parametre_Machine_Rechercher"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Paramètre", "Parametre_Type palette_Creer"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Paramètre", "Parametre_Type palette_Rechercher"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Paramètre", "Parametre_Emplacement_Creer"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Paramètre", "Parametre_Emplacement_Rechercher"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Paramètre", "Parametre_Processus"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Paramètre", "Parametre_Type activite"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Paramètre", "Parametre_Activite poste"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Paramètre", "Parametre_Activite processus"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Paramètre", "Parametre_Upload"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Gestion lot", "Gestion lot_Reception_Creation"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Gestion lot", "Gestion lot_Reception_Modification"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Gestion lot", "Gestion lot_Fabrication_Creation neuf"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Gestion lot", "Gestion lot_Fabrication_Modification neuf"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Gestion lot", "Gestion lot_Fabrication_Consultation neuf"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Gestion lot", "Gestion lot_Fabrication_Transfert SN neuf"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Gestion lot", "Gestion lot_Fabrication_Liberation SN neuf"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Gestion lot", "Gestion lot_Fabrication_Liberation neuf"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Gestion lot", "Gestion lot_Fabrication_Creation rechape"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Gestion lot", "Gestion lot_Fabrication_Modification rechape"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Réception", "Reception_Reception carcasse"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Réception", "Reception_Retour client"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Réception", "Reception_Donnees client"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Réception", "Reception_Depart de KCY"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Réception", "Reception_Arrivee a NWD"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification AVC", "Verification AVC_Renseigner le cru Bias"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification AVC", "Verification AVC_Renseigner le cru Bias - Assemblage"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification AVC", "Verification AVC_Renseigner le cru Bias - Rouletage Badigeon"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification AVC", "Verification AVC_Renseigner le cru Bias -Cuisson"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification AVC", "Verification AVC_Renseigner le cru Bias - Cuisson Reside"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification AVC", "Verification AVC_Renseigner le cru Bias -Classements dechet"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification AVC", "Verification AVC_Renseigner le cru Radial"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification AVC", "Verification AVC_Renseigner le cru Radial - Confection"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification AVC", "Verification AVC_Renseigner le cru Radial - Finition"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification AVC", "Verification AVC_Renseigner le cru Radial - Badigeon"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification AVC", "Verification AVC_Renseigner le cru Radial - Cuisson"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification AVC", "Verification AVC_Renseigner le cru Radial - Reparation"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification AVC", "Verification AVC_Premier examen"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification AVC", "Verification AVC_ERA"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification AVC", "Verification AVC_ANT"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification AVC", "Verification AVC_Shearo"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification AVC", "Verification AVC_Deuxieme examen"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification AVC", "Verification AVC_Examen ER"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Rechapage", "Rechapage_Enlevement pastille"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Rechapage", "Rechapage_Entree etuve"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Rechapage", "Rechapage_Sortie etuve"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Rechapage", "Rechapage_Cardage Bias"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Rechapage", "Rechapage_Cardage Radial"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Rechapage", "Rechapage_Enlevement BDR"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Rechapage", "Rechapage_Enlevement NSP"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Rechapage", "Rechapage_Brossage"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Rechapage", "Rechapage_Reparation"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Rechapage", "Rechapage_Dissolutionnage"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Rechapage", "Rechapage_BNS habillage"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Rechapage", "Rechapage_Gommage pose BDR"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Rechapage", "Rechapage_Cuisson"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification APC", "Verification APC_Classement cuisson par presse"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification APC", "Verification APC_Classement cuisson par SN"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification APC", "Verification APC_Hotline"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification APC", "Verification APC_Aspect"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification APC", "Verification APC_CVO"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification APC", "Verification APC_Scopie"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification APC", "Verification APC_ANT2"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification APC", "Verification APC_Shearo exterieure neuf"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification APC", "Verification APC_Shearo neuf"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification APC", "Verification APC_Shearo rechape"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification APC", "Verification APC_Uniformite BS1"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification APC", "Verification APC_Uniformite BS2"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification APC", "Verification APC_Uniformite pastillage"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification APC", "Verification APC_Uniformite pesee"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification APC", "Verification APC_Reparation R1"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification APC", "Verification APC_Reparation R3"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification APC", "Verification APC_Reside"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification APC", "Verification APC_Reutilisation"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification APC", "Verification APC_Inspection finale"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification APC", "Verification APC_Non - conformite_Creer par lot"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification APC", "Verification APC_Non-conformite_Creer par liste de SN"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification APC", "Verification APC_Non-conformite_Creer par SN"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Vérification APC", "Verification APC_Affectation des SN au lot"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Palettisation", "Palettisation_Montee en palette"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Palettisation", "Palettisation_Sortie palette"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Palettisation", "Palettisation_Reedition certificats"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Libération", "Liberation_Liberation produits finis"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Libération", "Liberation_Liberation individuelle"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Libération", "Liberation_Impression certificat differee"));
                menuSubmenu.Add(new KeyValuePair<string, string>("'GEODE", "GEODE_Montee en palette"));
                menuSubmenu.Add(new KeyValuePair<string, string>("'GEODE", "GEODE_Ajout palette"));
                menuSubmenu.Add(new KeyValuePair<string, string>("'GEODE", "GEODE_Sortie palette"));
                menuSubmenu.Add(new KeyValuePair<string, string>("'GEODE", "GEODE_Reedition consultation"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Qualité locale", "Qualite locale_Consultation activites SN"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Qualité locale", "Qualite locale_Consultation historique SN"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Qualité locale", "Qualite locale_Maj activites SN"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Qualité locale", "Qualite locale_Maj donnee SN"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Qualité locale", "Qualite locale_Suppression SN"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Qualité locale", "Qualite locale_Liste de SN pour CC"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Qualité locale", "Qualite locale_Blocage SN"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Qualité locale", "Qualite locale_Deblocage SN"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Qualité locale", "Qualite locale_Reedition etiquette reception"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Qualité locale", "Qualite locale_Reedition etiquette liberation"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Qualité locale", "Qualite locale_Reedition certificat SN"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Qualité locale", "Qualite locale_Reedition de plusieurs certificats SN"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Qualité locale", "Qualite locale_Suppression d'un certificat differe"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Qualité locale", "Qualite locale_Suppression de plusieurs certificats differes"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Qualité locale", "Qualite locale_SN illisible"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Qualité locale", "Qualite locale_Scrap SN"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Qualité locale", "Qualite locale_Message Hotline"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Qualité locale", "Qualite locale_Consigne_Creer"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Qualité locale", "Qualite locale_Consigne_Rechercher"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Qualité locale", "Qualite locale_Codes a barres a l'ecran"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Extraction", "Extraction_Bilan matricule neuf"));
                menuSubmenu.Add(new KeyValuePair<string, string>("Extraction", "Extraction_Bilan qualite neuf"));

            }
        }

        public static HeroCard GetAccessRequestSubMenuList(string name)
        {        

            List<Object> attachments = new List<Object>();
            var heroCard = new HeroCard
            {
                Title = "Please select the sub-menus to be allocated to the user for "+name,
                Buttons = new List<CardAction> { }
            };

            foreach (KeyValuePair<string, string> kvp in menuSubmenu)
            {
                if (kvp.Key == name)
                {
                    heroCard.Buttons.Add(new CardAction(ActionTypes.ImBack, kvp.Value, value: kvp.Value));
                }
            }
            

            return heroCard;
        }

        //shay
        public static HeroCard AppServiceCategory(string name)//only MOM APP FOR NOW
        {
            // Cards are sent as Attachments in the Bot Framework.
            // So we need to create a list of attachments for the reply activity.

            /*  foreach (KeyValuePair<string, string> kvp in docListMOMApp)
              {if(kvp.Key=="Connectivity issues")
                  {

                  }
              }

  */

            //  List<Attachment> attachments = new List<Attachment>();
            // attachments.Add(calculationIssues);
            // attachments.Add(connectivityIssues);
            // Reply to the activity we received with an activity.
            //var reply = MessageFactory.Attachment(attachments);
            List<KeyValuePair<string, Attachment>> issuesAndTheirDocs = EchoBotFinal.Resources.docList.MomApp();
            var heroCard = new HeroCard
            {//Please give us some more information about the issue so \n we can better help you.
                Title = "How would you categorize this issue?",
                Buttons = new List<CardAction> { }
            };


            foreach (KeyValuePair<string, Attachment> kvp in issuesAndTheirDocs)
            {
                heroCard.Buttons.Add(new CardAction(ActionTypes.ImBack, kvp.Key, value: kvp.Key));


            }


            return heroCard;
        }
        public static Attachment file()
        {
            // combine path for cross platform support
            string[] paths = { ".", "Resources", "adaptiveCard.json" };
            var adaptiveCardJson = File.ReadAllText(Path.Combine(paths));

            var adaptiveCardAttachment = new Attachment()
            {
                ContentType = "application/vnd.microsoft.card.adaptive",
                Content = JsonConvert.DeserializeObject(adaptiveCardJson),
            };
            return adaptiveCardAttachment;
        }
    }
    
}

