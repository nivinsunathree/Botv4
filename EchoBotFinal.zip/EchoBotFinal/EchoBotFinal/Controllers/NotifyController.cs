﻿// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

using System;
using System.Collections.Concurrent;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Integration.AspNet.Core;
using Microsoft.Bot.Connector;
using Microsoft.Bot.Connector.Authentication;
using Microsoft.Bot.Connector.Teams;
using Microsoft.Bot.Schema;
using Microsoft.Bot.Schema.Teams;
using Microsoft.Extensions.Configuration;
using Microsoft.Bot.Builder.BotFramework;
using System.Collections.Generic;

namespace Intelbot1.Controllers
{
    [Route("api/notify")]
    [ApiController]
    public class NotifyController : ControllerBase
    {
        public static bool notifWhenStateChanges = false;
        public static bool notifWhenAboutToKo = false;
        public static bool notifNewTickets = true;
        public static bool leaaccessrequest = false;
        public static bool notifyCommentsForm = false;
        private readonly IBotFrameworkHttpAdapter _adapter;
        private readonly string _appId;
        private readonly ConcurrentDictionary<string, ConversationReference> _conversationReferences;
       



        public NotifyController(IBotFrameworkHttpAdapter adapter, IConfiguration configuration, ConcurrentDictionary<string, ConversationReference> conversationReferences)
        {
            _adapter = adapter;
            _conversationReferences = conversationReferences;
            _appId = configuration["MicrosoftAppId"];
     
            // If the channel is the Emulator, and authentication is not in use,
            // the AppId will be null.  We generate a random AppId for this case only.
            // This is not required for production, since the AppId will have a value.
            if (string.IsNullOrEmpty(_appId))
            {
                _appId = Guid.NewGuid().ToString(); //if no AppId, use a random Guid
            }
        }

        public async Task<IActionResult> Get()
        {
            foreach (var conversationReference in _conversationReferences.Values)
            {
                if (notifNewTickets == true)
                    await ((BotAdapter)_adapter).ContinueConversationAsync(_appId, conversationReference, BotCallback, default(CancellationToken));
            }
            // Let the caller know proactive messages have been sent
            return new ContentResult()
            {
                Content = "<html><body><h1>Proactive messages have been sent.</h1></body></html>",
                ContentType = "text/html",
                StatusCode = (int)HttpStatusCode.OK,
            };

        }


        private async Task BotCallback(ITurnContext turnContext, CancellationToken cancellationToken)
        {

            
           
            if (notifNewTickets)
            {
                await turnContext.SendActivityAsync(MessageFactory.Text($"Hello!" + Environment.NewLine + $"Trust you are well" + Environment.NewLine + $"Hope that you are having a good day" + Environment.NewLine + $"We are contacting you concerning lea access requests" + Environment.NewLine + $"Could you please review the following tasks if any and add the required information!"), cancellationToken);
                //await turnContext.SendActivityAsync(MessageFactory.Text($"Please type ok to continue!"), cancellationToken);
                await turnContext.SendActivityAsync(MessageFactory.Text("Could you please click on the below button to continue?"));

                var card = new HeroCard
                {
                    //Text = "Could you please click on the below button to continue?",
                    Buttons = new List<CardAction>
                        {
                            new CardAction(ActionTypes.ImBack, title: "lea access request", value: "lea access request"),
                        },
                };
                var reply = MessageFactory.Attachment(card.ToAttachment());
                await turnContext.SendActivityAsync(reply, cancellationToken);
            }


        }
    }
}
