﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using Microsoft.Bot.Schema;
using Newtonsoft.Json;
using EchoBotFinal.Models;
using System.Diagnostics;
using Microsoft.Bot.Builder;
namespace EchoBotFinal.Resources
{
    public class docList
    { public static List<KeyValuePair<string, Attachment>>  MomApp(){
            List<KeyValuePair<string, Attachment>> docListMOMApp = new List<KeyValuePair<string, Attachment>>() { };
            string filePathconnectivityIssues = @"C:\Users\shayista.a.hosany\Desktop\EchoBotFinalv7\EchoBotFinal\EchoBotFinal\Resources\connectivityIssues.txt";
            var uriconnectivityIssues = new System.Uri(filePathconnectivityIssues);
            //ConnectorClient connector = new ConnectorClient(new Uri(activity.ServiceUrl));
            Attachment connectivityIssues = new Attachment()
            {

                ContentUrl = uriconnectivityIssues.AbsoluteUri,
                ContentType = "text/plain",
                Name = "connectivityIssues.txt"
            };
          

            string filePatharticuloIssues = @"C:\Users\shayista.a.hosany\Desktop\EchoBotFinalv7\EchoBotFinal\EchoBotFinal\Resources\articuloIssues.txt";
        var uriarticuloIssues = new System.Uri(filePatharticuloIssues);
        //ConnectorClient connector = new ConnectorClient(new Uri(activity.ServiceUrl));
        Attachment articuloIssues = new Attachment()
        {

            ContentUrl = uriarticuloIssues.AbsoluteUri,
            ContentType = "text/plain",
            Name = "articuloIssues.txt"
        };

        string filePathinterfaceIssues = @"C:\Users\shayista.a.hosany\Desktop\EchoBotFinalv7\EchoBotFinal\EchoBotFinal\Resources\interfaceIssues.txt";
        var uriinterfaceIssues = new System.Uri(filePathinterfaceIssues);
        //ConnectorClient connector = new ConnectorClient(new Uri(activity.ServiceUrl));
        Attachment interfaceIssues = new Attachment()
        {

            ContentUrl = uriinterfaceIssues.AbsoluteUri,
            ContentType = "text/plain",
            Name = "interfaceIssues.txt"
        };
            string filePathcalculationIssues = @"C:\Users\shayista.a.hosany\Desktop\EchoBotFinalv7\EchoBotFinal\EchoBotFinal\Resources\calculationIssues.txt";
            var uricalculationIssues = new System.Uri(filePathcalculationIssues);
            //ConnectorClient connector = new ConnectorClient(new Uri(activity.ServiceUrl));
            Attachment calculationIssues = new Attachment()
            {

                ContentUrl = uricalculationIssues.AbsoluteUri,
                ContentType = "text/plain",
                Name = "calculationIssues.txt"
            };
            string filePathparametersNotOkIssues = @"C:\Users\shayista.a.hosany\Desktop\EchoBotFinalv7\EchoBotFinal\EchoBotFinal\Resources\parametersNotOkIssues.txt";
            var uriparametersNotOkIssues = new System.Uri(filePathparametersNotOkIssues);
            //ConnectorClient connector = new ConnectorClient(new Uri(activity.ServiceUrl));
            Attachment parametersNotOkIssues = new Attachment()
            {

                ContentUrl = uriparametersNotOkIssues.AbsoluteUri,
                ContentType = "text/plain",
                Name = "parametersNotOkIssues.txt"
            };
            docListMOMApp.Add(new KeyValuePair<string, Attachment>("calculation issues", calculationIssues)); 
            docListMOMApp.Add(new KeyValuePair<string, Attachment>("connectivity issues", connectivityIssues));
            docListMOMApp.Add(new KeyValuePair<string, Attachment>("parameters not ok", parametersNotOkIssues));
            docListMOMApp.Add(new KeyValuePair<string, Attachment>("interface issues", interfaceIssues));
            docListMOMApp.Add(new KeyValuePair<string, Attachment>("articulo", articuloIssues));


            return docListMOMApp;
        }
    }
}
