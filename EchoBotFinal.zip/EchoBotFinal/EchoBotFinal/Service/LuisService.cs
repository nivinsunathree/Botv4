﻿using EchoBotFinal.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace EchoBotFinal.Service
{
    public class LuisService
    {
        public static async Task<LuisResponse> ParseUserInput(string input)
        {
            string returnValue=string.Empty;
            string escapedString = Uri.EscapeDataString(input);
            using(var client=new HttpClient())
            {
                string uri = $"https://westus.api.cognitive.microsoft.com/luis/v2.0/apps/d873a71a-ccb2-4a4a-9272-0f836a997267?verbose=true&timezoneOffset=-360&subscription-key=c1109289b07b47f2a8d3abf1fb281bb3&q={escapedString}";
                var msg = await client.GetAsync(uri);

                if (msg.IsSuccessStatusCode){
                    var jsonResponse = await msg.Content.ReadAsStringAsync();
                    
                        var data = JsonConvert.DeserializeObject<LuisResponse>(jsonResponse);
                        return data;
                    
                   
                }
            }
            return null;
        }
        
    }
}
